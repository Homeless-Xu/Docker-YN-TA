prompt ��ʼ�����ݣ����Ժ�......
declare
  sqlsta       varchar2(10000);
  sqlsta1      varchar2(10000);
  count1       number(9) :=1;
  count2       number(9) :=0;
  errmsg       varchar2(300);
begin
  
  loop
    exit when count1 = count2;
    count1 := count2;
    count2 := 0;
    for r1 in (select object_name,object_type from user_objects where object_type in ('VIEW','FUNCTION','PROCEDURE','PACKAGE') and status ='INVALID' order by created)
    loop
      sqlsta := 'alter '||r1.object_type||' '||r1.object_name||' compile';
      begin
        execute immediate sqlsta;
      exception
        when others then
          if sqlcode = -24344 then
            null;
          else
            raise;
          end if;
      end;
      count2 := count2 + 1;
    end loop;  

    for r1 in (select object_name,object_type from user_objects where object_type in ('PACKAGE BODY') and status ='INVALID' order by created)
    loop
      sqlsta := 'alter PACKAGE '||r1.object_name||' compile BODY';
      begin
        execute immediate sqlsta;
      exception
        when others then
          if sqlcode = -24344 then
            null;
          else
            raise;
          end if;
      end;
      count2 := count2 + 1;
    end loop;  
  end loop;
end;
/
quit